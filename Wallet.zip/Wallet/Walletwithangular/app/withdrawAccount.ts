import { Component } from "@angular/core";
import {AccountService} from './app.accountservice';

import { Withdraw } from "./models/Withdraw";
@Component({
    selector:'acc-withdraw',
    templateUrl:'withdraw.html'
})



export class WithdrawAccountComponent{
    constructor(private service:AccountService){}
    model:Withdraw=
    {
        id:0,
        amount:0
    }
    withdraw()
    {
        this.service.withdraw(this.model).subscribe(
            (data:any)=>console.log(data)
        )
    }
    
}