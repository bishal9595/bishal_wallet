import { Component } from "@angular/core";
import {AccountService} from './app.accountservice';
import {Transfer} from './models/Transfer';
@Component({
    selector:'acc-transfer',
    templateUrl:'transfer.html'
})
export class TransferAccountComponent{
    constructor(private service:AccountService){}
    model:Transfer=
    {
        aid1:0,
        aid2:0,
        amount:0
    }
    transfer()
    {
        this.service.transfer(this.model).subscribe(
            (data:any)=>console.log(data)
        )
    }
}