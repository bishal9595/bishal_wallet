export class Withdraw{
    id:number
    amount:number
}