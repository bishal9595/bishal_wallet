export interface Transfer{
    aid1:number
    aid2:number
    amount:number
}