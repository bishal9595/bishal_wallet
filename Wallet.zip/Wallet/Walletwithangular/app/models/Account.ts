export class Account{
    
    id:number;
    mobileNo:string;
    accountHolder:string;
    balance:number;
    constructor(id,mobileNo,accountHolder,balance)
    {
        this.id=id;
        this.mobileNo=mobileNo;
        this.accountHolder=accountHolder;
        this.balance=balance;
    }
}