import { Component} from "@angular/core";
import {AccountService} from './app.accountservice';
import {Account} from './models/Account';

@Component({
    selector:'acc-delete',
    templateUrl:'delete.html'
})

export class DeleteAccountComponent {
    
    id:number
    acc:Account
    constructor(private service:AccountService){}
    Delete()
    {
       this.service.delete(this.acc.id).subscribe(
      (err)=>{this.acc=err
        
       }
           
       )
    }


    flag=false;
    flag2=false;
    change()
    {
        this.flag=true;
  
    }
    change1()
    {
        this.flag2=true;
        this.flag=false;
        
       this.acc=null
        this.id=null
  
    }
    find()
    {
      console.log(this.id)
        this.service.searchAccount(this.id).subscribe(
            (data:Account)=>{
                this.acc=data
                this.change()
       

            },
            err=>{
                alert("Error!!!")
            }
        )     
    }
    

    
    
}