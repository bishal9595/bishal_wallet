import { Component, OnInit } from "@angular/core";
import {AccountService} from './app.accountservice';
import { Account } from "./models/Account";
@Component({
    selector:'add-acc',
    templateUrl:'app.addAccount.html'
})


export class AddAccountComponent implements OnInit{
    
    id:number;
    mobileNo:string;
    accountHolder:string;
    balance:number;
    acc:Account
    constructor(private service:AccountService){}
    ngOnInit(){}
  
    add()
    {
       
        var  account:Account=new Account(this.id,this.mobileNo,this.accountHolder,this.balance);
        this.service.createAccount(account).subscribe(
            (data:any)=>{
                this.acc=data
            }
        );     
    }   
flag=false;
    add_change(){
        this.flag=true;
    } 
}