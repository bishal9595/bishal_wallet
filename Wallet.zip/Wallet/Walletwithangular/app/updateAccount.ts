import { Component} from "@angular/core";
import {AccountService} from './app.accountservice';
import {Account} from './models/Account';
import { Router } from '@angular/router'

@Component({
    selector:'update',
    templateUrl:'update.html'
})

export class UpdateAccountComponent {
    model:Account={
        id:0,
        mobileNo:'',
        accountHolder:"",
        balance:0.0
    }
  
    acc:Account
    constructor(private service:AccountService,private router:Router){}
    update()
    {
       this.service.update(this.model,this.model.id).subscribe(
        (data:any)=>{this.acc=data
       }
         
       )
       this.router.navigate(['show'])  
    }
    
    
    
}