import { Component } from "@angular/core";
import {AccountService} from './app.accountservice';
import {Account} from "./models/Account";
@Component({
    selector:'search-acc',
    templateUrl:'searchAccount.html'
})



export class SearchAccountComponent{
    acc:Account
    constructor(private service:AccountService){}
    id:number;
    flag=false;
    change()
    {
        this.flag=true;
    }
    find()
    {
      console.log(this.id)
        this.service.searchAccount(this.id).subscribe(
            (data:Account)=>{
                this.acc=data
            },
            err=>{
                alert("Error!!!")
            }
        )     
    }
}