﻿import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent }  from './app.component';
import { AddAccountComponent } from './app.addAccount';
import { ShowAccountComponent } from './app.showAccount';
import { SearchAccountComponent } from './app.searchAccount';
import {FormsModule} from '@angular/forms';
import {Routes,RouterModule} from '@angular/router';
import {HttpClientModule} from '@angular/common/http';
import { UpdateAccountComponent } from './updateAccount';
import { DeleteAccountComponent } from './deleteAccount';
import { DepositAccountComponent } from './depositAccount';
import { WithdrawAccountComponent } from './withdrawAccount';
import { TransferAccountComponent } from './TransferAccount';
const routes:Routes=[
    {path:'',redirectTo:'show',pathMatch:'full'},
    {path:'add',component:AddAccountComponent},
    {path:'show',component:ShowAccountComponent},
    {path:'find',component:SearchAccountComponent},
    {path:'update',component:UpdateAccountComponent},
    {path:'delete',component:DeleteAccountComponent},
    {path:'withdraw',component: WithdrawAccountComponent},
    {path:'deposit',component:DepositAccountComponent},
    {path:'transfer',component:TransferAccountComponent},
    {path:'**',redirectTo:'show'},
];
@NgModule({
    imports: [
        BrowserModule,FormsModule,RouterModule.forRoot(routes),HttpClientModule
        
    ],
    declarations: [
        AppComponent,AddAccountComponent,ShowAccountComponent,SearchAccountComponent,UpdateAccountComponent,DeleteAccountComponent,DepositAccountComponent, WithdrawAccountComponent,TransferAccountComponent
		],
    providers: [ ],
    bootstrap: [AppComponent]
})

export class AppModule { }
