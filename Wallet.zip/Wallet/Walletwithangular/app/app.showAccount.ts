import { Component,} from "@angular/core";
import {AccountService} from './app.accountservice';
import {Account} from './models/Account';

@Component({
    selector:'show-acc',
    templateUrl:'showAccount.html'
})

export class ShowAccountComponent {
    constructor(private service:AccountService){}
    acc:Account[]=[];
    ngOnInit(): void {
        //throw new Error("Method not implemented.");
        this.service.getAccount().subscribe(
            (data:any)=>{
               this.acc=data
                console.log(this.acc);
                console.log(data)
            },
            err=>{
                alert("Error!!!!")
            }
        )
       } 


    
    
}