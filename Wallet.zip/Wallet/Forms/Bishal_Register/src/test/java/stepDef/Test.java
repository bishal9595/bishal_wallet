package stepDef;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Test {

	private WebDriver driver;
	private StudentRegister register;
	
	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver.exe" );
		driver= new ChromeDriver();
	}
	
	@Given("^User is on 'Registration' Page$")
	public void user_is_on_login_Page() throws Throwable {
	
		driver.get("file:///D:\\Users\\arusmani\\TestingAriz\\RegS\\register.html");
		register = new StudentRegister(driver);
	}
	
	@When("^user enters invalid Name$")
	public void user_enters_invalid_UserName() throws Throwable {
		register.setName("");
		register.setLoginButton();
	}

	@Then("^display 'Please Enter Name'$")
	public void display_Please_Enter_UserName() throws Throwable {
		String expectedMessage="*Please enter Name.";
		String actualMessage=register.getNameError().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		Thread.sleep(1000);
		driver.close();	
	}

	@When("^user enters invalid Address$")
	public void user_enters_invalid_Address() throws Throwable {
		register.setName("Bishal");
		register.setAddress("");
		register.setLoginButton();
	}

	@Then("^display 'Please Enter Addresss'$")
	public void display_Please_Enter_Addresss() throws Throwable {
		String expectedMessage="*Please enter Address.";
		String actualMessage=register.getAddressError().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		Thread.sleep(1000);
		driver.close();	
	}

	@When("^user enters invalid Marks$")
	public void user_enters_invalid_Marks() throws Throwable {
		register.setName("Bishal");
		register.setAddress("Pune");
		register.setMarks("");
		register.setLoginButton();
	}

	@Then("^display 'Please Enter Marks'$")
	public void display_Please_Enter_Marks() throws Throwable {
		String expectedMessage="*Please enter Marks.";
		String actualMessage=register.getMarksError().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		Thread.sleep(1000);
		driver.close();
	}
	
	@When("^user enters valid details$")
	public void user_enters_valid_details() throws Throwable {
		register.setName("Bishal");
		register.setAddress("Pune");
		register.setMarks("95");
		register.setLoginButton();
	}

	@Then("^go to 'Success'$")
	public void go_to_Success() throws Throwable {
		Thread.sleep(1000);
		driver.get("file:///D:\\Users\\arusmani\\TestingAriz\\RegS\\success.html");
	}

}
