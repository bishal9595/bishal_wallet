package com.cg.operations;

public class Deposit {
	private int aid;
	private double amount;
	
	public Deposit() {
		// TODO Auto-generated constructor stub
	}
	
	public Deposit(int aid, double amount) {
		super();
		this.aid = aid;
		this.amount = amount;
	}

	public int getAId() {
		return aid;
	}

	public void setAId(int aid) {
		this.aid = aid;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

}
