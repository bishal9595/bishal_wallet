package com.cg.Service;

import java.util.List;
import java.util.Optional;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.cg.daos.AccountDAO;
import com.cg.entities.Account;
import com.cg.exception.ApplicationException;


@Service
@Transactional
public class AccountServiceImpl implements AccountService {

	@Autowired AccountDAO dao; 
	
	Account a1 = new Account(101,"9999999999","Bishal",70000.0);
	Account a2 = new Account(102,"9999999998","Ashish",700000.0);
	Account a3 = new Account(103,"9999999997","Shamik",7500000.0);
	Account a4 = new Account(104,"9999999992","Rahul",45000.0);
	
	@PostConstruct
	public void sample() {
		addAccount(a1);
		addAccount(a2);
	    addAccount(a3);
	    addAccount(a4);
	}
	
	
	
	@Override
	@Transactional(propagation = Propagation.REQUIRED)
	public boolean addAccount(Account a) {
		if (dao.existsById(a.getId()))
			throw new ApplicationException("Account already exists!!"); // using custom exception to throw  if product already exists
		dao.save(a); // otherwise saving it in database
		
		System.out.println("Account is created");
		return true;
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED)
	public boolean deleteAccount(Account a) {
		if (!dao.existsById(a.getId()))
			throw new ApplicationException("Account doesn't exist!!"); // throwing custom exception if product doesn't exist
		else
			
			dao.deleteById(a.getId());
		
		return true;
	}

	@Override
	@Transactional(readOnly = true)
	public Account findAccount(int id) {
		Optional<Account> acc= dao.findById(id);
		if (acc.isPresent()) 
			return acc.get();
		else
			throw new ApplicationException("Account not found!!!!"); // throwing custom exception if product doesn't exist
	}

	@Override
	@Transactional(readOnly = true)
	public List<Account> getAllAccounts() {
		return dao.findAll();

		
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED)
	public double withdraw(Account ob, double amount) {
		double new_balance = ob.getBalance();
		if(amount > 0) {
			new_balance = ob.getBalance() - amount;
			if(new_balance < 1000.00) {
				new_balance = ob.getBalance();
				System.out.println("Insufficient Balance in the Account!!!");
				
				
			}
			else {
				ob.setBalance(new_balance);
				update(ob.getId(), ob);
			}
		}
		return 0;
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED)
	public double deposit(Account ob, double amount) {
		if(amount >= 0) {
			double new_balance = ob.getBalance() + amount;
			ob.setBalance(new_balance);
			
			update(ob.getId(), ob);
			
			return new_balance;
		}
		else {
			
			return ob.getBalance(); 
		}
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED)
	public double[] transferMoney(Account from, Account to, double amount) {
		double[] arr = new double[2];
		if(amount < 0) {
			System.out.println("Ammount cannot be negative,Invalid!!!");
			
			arr[0] = from.getBalance();
			arr[1] = to.getBalance();
			
		}
		else {
			double new_balance = from.getBalance() - amount;
			if(new_balance<1000.00) {
				
				System.out.println("Insufficient Balance");
				arr[0] = from.getBalance();
				arr[1] = to.getBalance();
				
			}
			else {
				from.setBalance(new_balance);
				arr[0] = from.getBalance();
				
				double b2 = to.getBalance()+amount;
				to.setBalance(b2);
				
				arr[1] = to.getBalance();
				
				update(from.getId(), from);
				update(to.getId(), to);
			}
		}
		return arr;
	}
	
	@Transactional(propagation = Propagation.REQUIRED)
	public void update(int id, Account account) {
		
		Optional<Account> p = dao.findById(id);
		if (p!=null) 
		{
			//account = p.get();
			dao.save(account);
		}
			
		else
			throw new ApplicationException("Account cannot be found!!!"); // throwing custom exception if account doesn't exist
		
		//a.setAccountHolder(account.getAccountHolder());
		//a.setBalance(account.getBalance());
		//a.setId(account.getId());
		//a.setMobileNo(account.getMobileNo());
	}

}
