package com.cg.operations;

public class Withdraw {
	
	private int aid;
	private double amount;
	
	public Withdraw() {
		// TODO Auto-generated constructor stub
	}
	
	public Withdraw(int aid, double amount) {
		super();
		this.aid = aid;
		this.amount = amount;
	}

	public int getAId() {
		return aid;
	}

	public void setId(int aid) {
		this.aid = aid;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

}
