package com.cg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.cg.operations.*;
import com.cg.Service.AccountService;
import com.cg.entities.Account;

@CrossOrigin("http://localhost:4200")
@RestController
@RequestMapping("/accounts")
public class AccountController {

	@Autowired 
	AccountService service;
	
	// to view all the available accounts
    @GetMapping(value = "/get")
	public List<Account> getAll() {
    	
		return service.getAllAccounts();
	}
    
      // To find a account by its Id
	@GetMapping(value = "/find/{id}")
	public Account findById(@PathVariable int id) {
		return service.findAccount(id);
	}
	
	// To create a new Account
	@PostMapping(value = "/new", consumes = { "application/json" })
	public String addAccount(@RequestBody Account account) {
		service.addAccount(account);
		return "Account added successfully to the database!!!";
	}
	
	// To update an existing account
	@PutMapping(value = "/update/{id}", consumes = { "application/json" })
	public String update(@RequestBody Account account, @PathVariable int id) {
		service.update(id, account);;
		return "Account updated successfully in the database!!!";
	}
	
	// To delete an existing account
	@DeleteMapping(value = "/delete/{id}")
	public String delete(@PathVariable int id) {
		Account a = service.findAccount(id);
		service.deleteAccount(a);
		return "deleted successfully";
	}
	
	// To withdraw money from an account using its Id
	@PutMapping(value = "/withdraw", consumes = { "application/json" })
	public double withdraw(@RequestBody Withdraw acc) {
		Account account = service.findAccount(acc.getAId());
		double with_amount = acc.getAmount();
		
		return service.withdraw(account, with_amount);
	}
	
	//To deposit money into the account by its Id
	@PutMapping(value = "/deposit", consumes = { "application/json" })
	public double deposit(@RequestBody Deposit acc) {
		System.out.println("Deposit acc "+acc.getAId()+acc.getAmount());
		Account account = service.findAccount(acc.getAId());
		
		double dep_amount = acc.getAmount();
		
		return service.deposit(account, dep_amount);
	}
    
	//To transfer money from one account to another account by using their Id's
	@PutMapping(value = "/transfer", consumes = { "application/json" })
	public double[] transferMoney(@RequestBody Transfer acc) {
		
		int id1 = acc.getAId1();
		int id2 = acc.getAId2();
		double transfer_amount = acc.getAmount();
		
		Account from_acc = service.findAccount(id1);
		Account to_acc = service.findAccount(id2);
		
		return service.transferMoney(from_acc, to_acc, transfer_amount);
	}


}
