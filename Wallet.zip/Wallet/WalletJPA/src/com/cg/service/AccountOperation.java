package com.cg.service;

import java.util.*;

import com.cg.bean.Account;
import com.cg.exception.InsufficientFundException;

public interface AccountOperation {
	public boolean addAccount(Account ob);
	public boolean updateAccount(long mobileno,String ah);
	public boolean deleteAccount(long mobileno);
	public Account findAccount(long mobileno);
	public List<Account> getAllAccounts();
	
	

	public void transferMoney(long from, long to, double amount) throws InsufficientFundException;
	public boolean deposit(long mobileno,double amount);
	public boolean withdraw(long mobileno,double amount) throws InsufficientFundException;
}
