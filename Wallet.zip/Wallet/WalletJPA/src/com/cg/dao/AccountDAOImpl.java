package com.cg.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;
import javax.persistence.Query;


import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.bean.Account;
import com.cg.exception.InsufficientFundException;

public class AccountDAOImpl implements AccountDAO {
	EntityManagerFactory emf=Persistence.createEntityManagerFactory("JPA-PU");
	EntityManager em=emf.createEntityManager();
  
	@Override
	
	public boolean addAccount(Account ob) {
		// TODO Auto-generated method stub
		em.getTransaction().begin();
		em.persist(ob);
		em.flush();
		em.getTransaction().commit();
		return true;
	}

	@Override
	public boolean updateAccount(long mobileno, String ah) {
		// TODO Auto-generated method stub
		Account ob=em.find(Account.class,mobileno);
		
		em.getTransaction().begin();
	    ob.setAccountholder(ah);
	    em.merge(ob);
	
	em.getTransaction().commit();
		return true;
	
	}

	@Override
	public boolean deleteAccount(long mobileno) {
		// TODO Auto-generated method stub
		em.getTransaction().begin();
		String query="delete from  Account a  where a.mobile="+mobileno;
		Query q=em.createQuery(query);
		q.executeUpdate();
		em.getTransaction().commit();
		return true;
	}

	@Override
	public Account findAccount(long mobileno) {
		// TODO Auto-generated method stub
		Account ob =em.find(Account.class, mobileno);
		return ob;
	}

	@Override
	public List< Account> getAllAccounts() {
		// TODO Auto-generated method stub
		String query="select a from Account a ";
		Query q=em.createQuery(query);
		List<Account> acclist=q.getResultList();
		
		return acclist;
	}

	@Override
	public void transferMoney(long from, long to, double amount) throws InsufficientFundException {
		// TODO Auto-generated method stub
		Account ob=em.find(Account.class,from);
		Account ob1=em.find(Account.class,to);
		double new_bal=ob.getBalance()-amount;
		if(new_bal<1000) {
			new_bal=ob.getBalance();
			throw new InsufficientFundException("Insufficient fund",new_bal);
		}
		em.getTransaction().begin();
		ob.setBalance(new_bal);
		em.getTransaction().commit();
		em.getTransaction().begin();
		double new_bal1=ob1.getBalance()+amount;
		ob1.setBalance(new_bal1);
		em.getTransaction().commit();
		
		
		
	}

	@Override
	public boolean deposit(long mobileno, double amount) {
		// TODO Auto-generated method stub
		Account ob=em.find(Account.class,mobileno);
		em.getTransaction().begin();
		double new_bal=ob.getBalance()+amount;
		ob.setBalance(new_bal);
		em.getTransaction().commit();
		return true;
	}

	@Override
	public boolean withdraw(long mobileno, double amount) throws InsufficientFundException {
		// TODO Auto-generated method stub
		Account ob=em.find(Account.class,mobileno);
		double new_bal=ob.getBalance()-amount;
		if(new_bal<1000) {
			new_bal=ob.getBalance();
			throw new InsufficientFundException("Insufficient fund",new_bal);
		}
		em.getTransaction().begin();
		ob.setBalance(new_bal);
		em.getTransaction().commit();
		return false;
	}

	@Override
	public void exit() {
		// TODO Auto-generated method stub
		
		System.exit(0);
	}
	
	}
