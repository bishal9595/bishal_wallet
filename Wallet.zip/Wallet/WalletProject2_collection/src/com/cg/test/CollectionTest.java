package com.cg.test;
import com.cg.service.*;

import com.cg.bean.*;
import com.cg.exception.InsufficientFundException;

import java.sql.SQLException;
import java.util.*;
import com.cg.dao.*;

import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.*;

import org.easymock.EasyMock;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;

class CollectionTest {
	Scanner sc=new Scanner(System.in);
	private AccountService service;
	private AccountDAO mockDao;
	@Test
	void testwithdraw() throws InsufficientFundException, SQLException {
		Account a= new Account();
		
		a.setBalance(50000);
		AccountService as=new AccountService();
		assertEquals(45000,as.withdraw(a,5000));
		//assertTrue(a.getBalance()>=5000);
		assertThrows(InsufficientFundException.class,()->as.withdraw(a,44500));
	}
	
	@Test
	void testdeposite()
	{
		
		
		Account a= new Account();
		a.setBalance(50000);
		AccountService as=new AccountService();
		
		assertEquals(55000,as.deposite(a,5000));
		//assertTrue(a.getBalance()>=5000);
	}
	
	
	@Test
	void testtransfermoney() 
	{ 
	Account a= new Account();
	a.setBalance(50000.0);
	Account b= new Account();
	b.setBalance(40000.0);
	AccountService as=new AccountService();
	double c[]=as.transferMoney(a,b,5000.0);
	c[0]=a.getBalance();
	c[1]=b.getBalance();
	assertEquals(45000.0,c[0]);
	assertEquals(45000.0,c[1]);

	
	}
	
	
	@Test
	void testcalculatetax()
	{   AccountService as=new AccountService();
		assertEquals(250,as.calculateTax(Gst.PCT_5,5000));
	}
	
	
	@Test
	void testaddcaccount() throws SQLException
	{ Account a1= new Account(101,1234567890,"Ram",45000.00);
	AccountService as=new AccountService();
	//Map<Long,Account> a2=new HashMap<Long,Account>();
	
	assertTrue(as.addAccount(a1));
	}
	
	
	@Test
	void testfindaccount()
	{   service=new AccountService();
	
	    Account a=new Account();
	    
	    long m=1234567890L;
	    a.setMobile(m);
	    mockDao = EasyMock.createMock(AccountDAO.class);
	    service.setDao(mockDao);
	    EasyMock.expect
		(mockDao.findAccount(m)).andReturn(a);
	    EasyMock.replay(mockDao);
	    assertTrue(service.findAccount(m)!=null);
	    EasyMock.verify(mockDao);
	    
	}
}
