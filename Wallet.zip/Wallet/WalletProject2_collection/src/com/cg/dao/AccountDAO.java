package com.cg.dao;

import java.sql.SQLException;
import java.util.Map;

import com.cg.bean.Account;

public interface AccountDAO {
    public boolean addAccount(Account ob) ;
    public boolean updateAccount(long mobileno,String ah);
    public boolean deleteAccount(Account ob) ;
    //public boolean display();
    public Account findAccount(Long mobileno);
    public Map<Long,Account> getAllAccounts();
    //public boolean transferMoney(Account from,Account to);

}
