package com.cg.entities;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="accountwallet")
public class Account {
	
	@Id
	
	private Integer id;
	
	@Column(length=10)
	private String mobileNo;
	
	@Column(length=30)
	private String accountHolder;
	
	
	private double balance;
	
	public Account() {
	
	}

	public Account(Integer id,String mobileno, String accountHolder, double balance) {
		super();
		this.id = id;
		this.mobileNo = mobileno;
		this.accountHolder = accountHolder;
		this.balance = balance;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer aid) {
		this.id = aid;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileno) {
		this.mobileNo = mobileno;
	}

	public String getAccountHolder() {
		return accountHolder;
	}

	public void setAccountHolder(String accountHolder) {
		this.accountHolder = accountHolder;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	@Override
	public String toString() {
		return "Account [Account id=" + id + ", Mobile Number=" + mobileNo + ", Account Holder's name=" + accountHolder + ", balance=" + balance + "]";
	}
	
}