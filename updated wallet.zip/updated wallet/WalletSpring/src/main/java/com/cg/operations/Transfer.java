package com.cg.operations;

public class Transfer {
	
	private int aid1;
	private int aid2;
	private double amount;
	
	public Transfer() {
		// TODO Auto-generated constructor stub
	}
	
	public Transfer(int id1, int id2, double amount) {
		super();
		this.aid1 = id1;
		this.aid2 = id2;
		this.amount = amount;
	}

	public int getAId1() {
		return aid1;
	}

	public void setAId1(int id1) {
		this.aid1 = id1;
	}

	public int getAId2() {
		return aid2;
	}

	public void setId2(int aid2) {
		this.aid2 = aid2;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

}
