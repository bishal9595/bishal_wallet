import { Component} from "@angular/core";
import {AccountService} from './app.accountservice';
import {Account} from './models/Account';
import { Router } from '@angular/router'

@Component({
    selector:'update',
    templateUrl:'update.html'
})

export class UpdateAccountComponent {
    error:Error
    model:Account={
        id:0,
        mobileNo:'',
        accountHolder:"",
        balance:0.0
    }
  
    acc:Account
    constructor(private service:AccountService){}
    update()
    {
       this.service.update(this.model,this.model.id).subscribe(
        res=>{this.acc=res
            
            
       },
       error=>{
       
           this.error=error;
           console.log(this.error)
       }
       
           
       )
    }
    
    

    
    
    
}