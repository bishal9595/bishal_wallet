import { Component } from "@angular/core";
import {AccountService} from './app.accountservice';

import { Withdraw } from "./models/Withdraw";
@Component({
    selector:'acc-withdraw',
    templateUrl:'withdraw.html'
})



export class WithdrawAccountComponent{
  acc:number
    amt1=false
    isError=false
    err:Error
    isNeget=false
    constructor(private service:AccountService){}
    model:Withdraw=
    {
        id:0,
        amount:0
    }
    withdraw()
    {
        this.service.withdraw(this.model).subscribe(
            data=>
               console.log(data),
                err=>
                this.err=err
               
            
        )
    }

    reLoad(){
        window.location.reload()
    }
    ch=false
    change()
    {
        this.ch=true;
    }
    
}