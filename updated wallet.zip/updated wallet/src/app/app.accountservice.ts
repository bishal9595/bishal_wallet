import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders } from "@angular/common/http";
import {Observable} from 'rxjs';
import {Account} from './models/Account';
import { Deposit } from "./models/Deposit";
import { Withdraw } from "./models/Withdraw";
import { Transfer } from "./models/Transfer";

let baseUrl = "http://localhost:6011/accounts";

@Injectable({
    providedIn:'root'
})

export class AccountService{
    constructor(private http:HttpClient){}

    acc:Account;
    createAccount(account: Account) :Observable<Account> 
    {
        let options = { "headers": 
                    new HttpHeaders({"Content-Type": "application/json" }) };
         return this.http.post<Account>(baseUrl + "/new",account,options);
    }

    getAccount()
    {       
          return this.http.get<Account[]>(baseUrl+"/get");
    }
    searchAccount(id:number){
        let options = { "headers": 
        new HttpHeaders({"Content-Type": "application/json" }) };
        return this.http.get<Account>(baseUrl+"/find/"+id,options);

    }
    update(account:Account,id:number)
    {
        let options = { "headers": 
        new HttpHeaders({"Content-Type": "application/json" }) };
        return this.http.put<Account>(baseUrl+"/update/"+id,account,options);

    }
    delete(id:number)
    {
        let options = { "headers": 
        new HttpHeaders({"Content-Type": "application/json" }) };
        return this.http.delete<Account>(baseUrl+"/delete/"+id,options);

    }
    deposit(model:Deposit)
    {
        let options = { "headers": 
        new HttpHeaders({"Content-Type": "application/json" }) };
        return this.http.put<Account>(baseUrl+"/deposit",model,options)
    }
    withdraw(model:Withdraw)
    {
        let options = { "headers": 
        new HttpHeaders({"Content-Type": "application/json" }) };
        return this.http.put<Account>(baseUrl+"/withdraw",model,options)
    }
    transfer(model:Transfer){
        let options = { "headers": 
        new HttpHeaders({"Content-Type": "application/json" }) };
        return this.http.put<Account>(baseUrl+"/transfer",model,options)
    }
}

   