import { Component } from "@angular/core";
import {AccountService} from './app.accountservice';

import { Deposit } from "./models/Deposit";
@Component({
    selector:'acc-deposit',
    templateUrl:'deposit.html'
})



export class DepositAccountComponent{
    constructor(private service:AccountService){}
    model:Deposit=
    {
        aid:0,
        amount:0
    }
    deposit()
    {   console.log(this.model)
        this.service.deposit(this.model).subscribe(
            (data:any)=>console.log(data)
        )
    }
}