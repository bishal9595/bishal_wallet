export class Transfer{
    aid1:number
    aid2:number
    amount:number
}