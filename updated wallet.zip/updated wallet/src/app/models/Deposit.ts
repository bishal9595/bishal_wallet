export class Deposit{
    aid:number
    amount:number
}