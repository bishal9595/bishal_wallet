package com.cg.service;
import java.sql.*;
import java.util.Map;

import com.cg.bean.Account;
import com.cg.dao.AccountDAO;
import com.cg.dao.AccountDAOImpl;
import com.cg.exception.InsufficientFundException;
public class AccountService implements Gst,Transaction {
   AccountDAO dao=new AccountDAOImpl();
  
    public void setDao( AccountDAO dao) 
   {
	   this.dao=dao;
   }
   public boolean addAccount(Account ob)
   {
	    dao.addAccount(ob);
	    return true;
   }
   public boolean deleteAccount(Account ob) 
   {
	   
	   dao.deleteAccount(ob);
	   return true;
   }
 
	@Override
	public double withdraw(Account ob, double amount) throws InsufficientFundException, SQLException {
			// TODO Auto-generated method stub
		  if(amount>0) {
			double new_balance=ob.getBalance()-amount;
			if(new_balance<1000.00)
			{
			new_balance=ob.getBalance();
			//throw new RuntimeException("Insufficient Balance");
			throw new InsufficientFundException("Insufficient Fund.Can not process withdraw",new_balance);
			}
			ob.setBalance(new_balance);
			return new_balance;
			}
		  else {
			  System.out.println("amt cannot be negative");
			  return 0.0;
		  }
		  
		  }

	@Override
	public double deposite(Account ob, double amount) {
		if(amount>0) {
		double new_balance=ob.getBalance()+amount;
		ob.setBalance(new_balance);
		
		// TODO Auto-generated method stub
		return new_balance;
		}
		else
		return 0.0;
	}
	@Override
	public double[] transferMoney(Account from, Account to, double amount) throws InsufficientFundException  {
		// TODO Auto-generated method stub
		double c[]=new double[2];
		double new_balance=from.getBalance()-amount;
		if(new_balance<1000.00) {
			//System.out.println("Insufficient balance");
		     // c[0]=new_balance;
			//return c;
			throw new InsufficientFundException("Insufficient Fund.Can not transfer",new_balance);
		
		}
		from.setBalance(new_balance);
		double b2=to.getBalance()+amount;
		c[1]=b2;
		to.setBalance(c[1]);
		//String ans="From account: "+from.getAid()+" Balance: "+from.getBalance()+"\n"+"To account: "+to.getAid()+"Balance: "+to.getBalance();
		return c;
		
		
	}
	

	@Override
	public double calculateTax(double PCT, double amount) {
		// TODO Auto-generated method stub
		return amount*Gst.PCT_5;
	}
	@Override
	public Account findAccount(Long mobileno) {
		// TODO Auto-generated method stub
		return dao.findAccount(mobileno);
	}
	@Override
	public Map<Long, Account> getAllAccounts() {
		// TODO Auto-generated method stub
		return dao.getAllAccounts();
	}
	@Override
	public boolean updateAccount(long mobileno, String ah) {
		// TODO Auto-generated method stub
		return dao.updateAccount(mobileno,ah);
	}

}
