package com.cg.dao;

import java.sql.*;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import com.cg.bean.Account;

public class AccountDAOImpl implements AccountDAO {
    public Map<Long,Account> accmap=new HashMap<Long,Account>();
 /*  public Connection jdbc() throws SQLException
   {
	   try {
    	   Class.forName("oracle.jdbc.driver.OracleDriver");
    	   
       }
       catch(ClassNotFoundException e)
       {
    	   e.printStackTrace();
       }
       
       String url="jdbc:oracle:thin:@localhost:1521:xe";
       String user="hr";
       String pass="hr";
       Connection con=DriverManager.getConnection(url,user,pass);
       return con;
   }*/
	
	
    public AccountDAOImpl(){}
	@Override
	public boolean addAccount(Account ob)   {
		// TODO Auto-generated method stub
		accmap.put(ob.getMobile(), ob);
		
		
		
		return true;
	}

	@Override
	public boolean updateAccount(long mobileno,String ah) {
		// TODO Auto-generated method stub
		Account ob1=accmap.get(mobileno);
		ob1.setAccountholder(ah);
		return true;
	}
	@Override
	public boolean deleteAccount(Account ob)  {
		// TODO Auto-generated method stub
		accmap.remove(ob.getMobile());
		
		
		return true;
	}
	
     
	

	@Override
	public Account findAccount(Long mobileno) {
		// TODO Auto-generated method stub
		Account ob=accmap.get(mobileno);
		
		
		return ob;
	}

	@Override
	public Map<Long, Account> getAllAccounts() {
		// TODO Auto-generated method stub
		return accmap;
	}

	
	

	
    
}
