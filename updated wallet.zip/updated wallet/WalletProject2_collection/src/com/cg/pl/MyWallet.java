package com.cg.pl;
import com.cg.bean.*;
import com.cg.dao.AccountDAOImpl;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.*;
import com.cg.service.*;
import com.cg.exception.InsufficientFundException;
import java.sql.*;
public class MyWallet {
	public static void main(String[] args) throws InsufficientFundException, IOException,SQLException {
		
		
		AccountService service=new AccountService();
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
        String choice="";
		  while(true) {
	           System.out.println("Menu");
	           System.out.println("========");
	           System.out.println("========");
	           System.out.println("1.Create new Account");
	           System.out.println("2.Print all accounts");
	           System.out.println("3.withdraw money from account");
	           System.out.println("4.delete account");
	           System.out.println("5.transfer money");
	           System.out.println("6.deposit money");
	           System.out.println("7.Update Account");
	           System.out.println("8.Exit");
	           System.out.println("Enter your choice");
	           choice=br.readLine();
	           switch(choice) {
	           case "1":  int id=0;
	                      long mb=0L;
	                      String ah="";
	                      double bal=0.0;
	                      // Accepting and validating input for Account number
	                      System.out.println("Enter account number");
	                      while(true)
	                      {
	                    	  String s_id=br.readLine();
	                    	  boolean ch1=Validator.validatedata(s_id, Validator.aidpattern);
	                    	  if(ch1==true)
	                    	  {
	                    		  try {
	                    			  id=Integer.parseInt(s_id);
	                    			  break;
	                    		  }
	                    		  catch(NumberFormatException e)
	                    		  {
	                    			  System.out.println("Account number must be numeric.Re enter");
	                    		  }
	                    	  }
	                    	  else
	                    	  {
	                    		  System.out.println("Re enter Account number");
	                    	  }
	                      }//end of account number while
	                      System.out.println("Enter mobile number");
	                      while(true)
	                      {
	                    	  String s_mb=br.readLine();
	                    	  boolean ch1=Validator.validatedata(s_mb, Validator.mobilepattern);
	                    	  if(ch1==true)
	                    	  {
	                    		  try {
	                    			 mb=Long.parseLong(s_mb);
	                    			  break;
	                    		  }
	                    		  catch(NumberFormatException e)
	                    		  {
	                    			  System.out.println("Mobile Number must be numeric.Re enter");
	                    		  }
	                    	  }
	                    	  else
	                    	  {
	                    		  System.out.println("Re Enter Mobile number");
	                    	  }
	                      }//end of mobile number while
	                      
	                      
	                      
	                      //accepting and validating account holder
	                      System.out.println("Enter Account holder name");
	                      while(true)
	                      {  
	                              
	                    	  String s_ah=br.readLine();
	                    	  boolean ch1=Validator.validatedata(s_ah, Validator.namepattern);
	                    	  if(ch1==true)
	                    	  {
	                    		  try {
	                    			 ah=s_ah;
	                    			  break;
	                    		  }
	                    		  catch(NumberFormatException e)
	                    		  {
	                    			  System.out.println("name must be string.Re enter");
	                    		  }
	                    	  }
	                    	  else
	                    	  {
	                    		  System.out.println("Re Account holder name");
	                    	  }
	                      }
	                       
	                     
	                      
	                      //accepting and validating balance
	                     
	                      System.out.println("Enter balance");
                          
	                      while(true)
	                      {  
	                    	  String s_bal=br.readLine();
	                    	  boolean ch1=Validator.validatedata(s_bal, Validator.balancepattern);
	                    	  if(ch1==true)
	                    	  {
	                    		  try {
	                    			  bal=Double.parseDouble(s_bal);
	                    			  break;
	                    		  }
	                    		  catch(NumberFormatException e)
	                    		  {
	                    			  System.out.println("Error.Re enter");
	                    		  }
	                    	  } 
	                    	  else
	                    	  {
	                    		  System.out.println("Re Enter Balance");
	                    	  }
	                      }//end of mobile number while
	                     
	                     Account ob=new Account(id,mb,ah,bal);
	                    
	                     
	                     service.addAccount(ob);
	                     break;
	                     
	           case "2":
	        	                  Collection<Account> vc=service.getAllAccounts().values();
	        	                   List<Account> acclist=new ArrayList<Account>(vc);
	        	                   for(Account a:acclist)
	        	                   {
	        	                	  service.printStatement(a);
	        	                   }
	                                break;
	                                
	           case "3":            System.out.println("enter mobile number");
                                  long accid=Long.parseLong(br.readLine());
                                     System.out.println("enter amount");
                                   double am=Double.parseDouble(br.readLine());
                                  service.withdraw(service.findAccount(accid), am);
                                   break;
	           case "4":           System.out.println("enter mobile number");
                                       long axcid=Long.parseLong(br.readLine());
                                       service.deleteAccount(service.findAccount(axcid));  
                                    break;
	              
	             
	           case "5":           System.out.println("enter from mobile number");
	                                     long acid=Long.parseLong(br.readLine());
	                                     System.out.println("enter to mobile number");
	                                     long tccid=Long.parseLong(br.readLine());
	                                     System.out.println("enter amount");
	                                     double amt=Double.parseDouble(br.readLine());
	                                     try {
	                                     service.transferMoney(service.findAccount(acid),service.findAccount(tccid),amt);
	                                     }
	                                    catch(InsufficientFundException e)
	                                     {
	                                    	System.out.println(e.getMessage());
	                                     }
	                                     break;
	           case "6":            System.out.println("enter mobile number");
                                  long n=Long.parseLong(br.readLine());
                                   System.out.println("enter amount");
                                 double ao=Double.parseDouble(br.readLine());
                                 service.deposite(service.findAccount(n), ao);
                                   break;
                                   
	           case "7":         System.out.println("enter mobile number");
                                 long n2=Long.parseLong(br.readLine());
                                 System.out.println("enter the name for update");
                                 String name=br.readLine();
                                 service.updateAccount(n2,name);
                                 break;
                                 
                                 
                     case "8":           System.out.println("exiting program");
                                         System.exit(0);
                                           break;
	               default:    System.out.println("Invalid choice");
	           }}
		
		
		
	
}}